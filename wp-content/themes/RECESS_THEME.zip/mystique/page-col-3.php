<?php /* Mystique/digitalnature

 Template Name: 3 column page
 */
 
 include(TEMPLATEPATH . '/page.php');
 // exactly the same as page.php (only file name is needed for the check)
?>
