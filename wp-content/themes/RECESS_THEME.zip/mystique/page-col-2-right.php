<?php /* Mystique/digitalnature

 Template Name: 2 columns page (right sidebar, default)
 */
 
 include(TEMPLATEPATH . '/page.php');
 // exactly the same as page.php (only file name is needed for the check)
?>
