<?php /* Mystique/digitalnature

 Template Name: 2 column page (left sidebar)
 */
 
 include(TEMPLATEPATH . '/page.php');
 // exactly the same as page.php (only file name is needed for the check)
?>
