<?php /* Mystique/digitalnature

 Template Name: 1 column page (no sidebars)
 */

 include(TEMPLATEPATH . '/page.php');
 // exactly the same as page.php (template filename is used for the check)
?>
