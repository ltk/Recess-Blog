<?php /* Mystique/digitalnature

 Template Name: Featured posts
 */

 include(TEMPLATEPATH . '/page.php');
 // exactly the same as page.php (template filename is used for the check)
?>
